#ifndef TEST_H
#define TEST_H

int client();
int server();

#endif /* TEST_H */