# opencv_video_capture_tcp_display
using opencv capture/display pc_camera video through TCP
