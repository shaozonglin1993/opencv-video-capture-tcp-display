#include "test.h"

int main()
{
	client();
//	server();
	return 0;
}
